from une_ai.models import Agent

class ConnectFourPlayer(Agent):

    def __init__(self, agent_name, agent_program):
        super().__init__(agent_name, agent_program)

    # TODO
    # add all the necessary sensors as per the requirements
    def add_all_sensors(self):
        pass

    # TODO
    # add all the necessary actuators as per the requirements
    def add_all_actuators(self):
        pass

    # TODO
    # add all the necessary actions as per the requirements
    def add_all_actions(self):
        pass